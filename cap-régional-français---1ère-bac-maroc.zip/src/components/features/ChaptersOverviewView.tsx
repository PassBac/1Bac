import React, { useState } from 'react';
import { QuizChapterBank, LexiqueData, UserStudyProgress } from '../../types';
import {
  CheckCircle2,
  Circle,
  ArrowRight,
  HelpCircle,
  Sparkles,
  BookOpen,
  Calendar,
  MapPin,
  Users,
  Search,
  Filter,
  Layers,
  ChevronDown,
  ChevronUp,
  BookmarkCheck,
  Award
} from 'lucide-react';

interface ChaptersOverviewViewProps {
  quizBanks: QuizChapterBank[];
  lexiqueData: LexiqueData;
  progress: UserStudyProgress;
  onOpenQuiz: (chapterIndex: number) => void;
  onToggleChapter: (chapterId: string) => void;
  onOpenFlashcards: () => void;
}

export const ChaptersOverviewView: React.FC<ChaptersOverviewViewProps> = ({
  quizBanks,
  lexiqueData,
  progress,
  onOpenQuiz,
  onToggleChapter,
  onOpenFlashcards,
}) => {
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedChapterId, setExpandedChapterId] = useState<string | null>('chapitre-1');

  // Comprehensive professional syllabus data according to Moroccan Regional Exam reference framework
  const chaptersSyllabus = [
    {
      id: 'chapitre-1',
      number: 1,
      season: 'Hiver',
      spatialFrame: 'Dar Chouafa & Le Bain Maure',
      title: 'La Solitude, Dar Chouafa, le Bain Maure et la Querelle de lessive',
      narrativeArc:
        'Incipit marquant sur la solitude nocturne de l\'enfant. Présentation de Dar Chouafa et de ses locataires. Visite étouffante au bain maure avec la mère (enfer dantesque). Querelle violente entre Lalla Zoubida et Rahma le lendemain pour l\'usage de la terrasse.',
      regionalExamKeys: [
        'Situation du passage : Incipit du roman, présentation du narrateur et du cadre spatial.',
        'Thèmes dominants : La solitude existentielle, la promiscuité sociale, l\'univers des femmes.',
        'Figures de style types : Comparaison ("seul comme un petit moineau"), métaphore, hyperbole lors de la dispute.',
        'La Boîte à merveilles : Premier refuge contre la solitude, monde féerique opposé au réel.'
      ],
      themes: ['Solitude de l\'enfant', 'Dar Chouafa', 'Bain maure', 'Querelle des lessives', 'Objets-talismans'],
      keyCharacters: [
        { name: 'Sidi Mohammed', role: 'Narrateur (6 ans)' },
        { name: 'Lalla Zoubida', role: 'Mère du narrateur' },
        { name: 'Lalla Kenza', role: 'La Chouafa (rez-de-chaussée)' },
        { name: 'Rahma & Driss', role: 'Voisins du 2e étage' },
        { name: 'Fatma Bziouya', role: 'Voisine du 1er étage' }
      ],
      examQuestionsHint: 'Très fréquent au régional : Situer le passage de l\'incipit ou analyser la tonalité polémique de la dispute.'
    },
    {
      id: 'chapitre-2',
      number: 2,
      season: 'Hiver',
      spatialFrame: 'Le Msid & Le Sanctuaire Sidi Ali Boughaleb',
      title: 'Le Msid, le Mardi Funeste et la Visite au Sanctuaire',
      narrativeArc:
        'L\'angoisse du mardi au Msid sous l\'œil sévère du Fqih armé de sa baguette de cognassier. Lalla Zoubida trouve son fils fiévreux et pâle. Accompagnée de son amie intime Lalla Aïcha, elle emmène Sidi Mohammed au mausolée de Sidi Ali Boughaleb. Sidi Mohammed est griffé par un chat.',
      regionalExamKeys: [
        'Situation du passage : Lendemain de la fièvre, visite maraboutique pour guérir le narrateur.',
        'Thèmes dominants : L\'angoisse scolaire traditionnelle, les croyances populaires (maraboutisme, baraka).',
        'Figures de style types : Hyperbole de la peur du fqih, personnification du sanctuaire et des chats sacrés.',
        'Rôle de Lalla Aïcha : Apparition de la confidente fidèle de la mère.'
      ],
      themes: ['Le Msid', 'Le Fqih', 'Baguette de cognassier', 'Maraboutisme', 'Le chat griffon'],
      keyCharacters: [
        { name: 'Le Fqih', role: 'Maître d\'école coranique' },
        { name: 'Lalla Aïcha', role: 'Amie fidèle et confidente' },
        { name: 'Sidi Ali Boughaleb', role: 'Saint patron protecteur' },
        { name: 'Lalla Zoubida', role: 'Mère protectrice et croyante' }
      ],
      examQuestionsHint: 'Sujet classique : L\'opposition entre l\'enfermement du Msid et la liberté imaginaire de l\'enfant.'
    },
    {
      id: 'chapitre-3',
      number: 3,
      season: 'Hiver',
      spatialFrame: 'Dar Chouafa & Dar Kitoun',
      title: 'La Lampe à Pétrole, la Disparition de Zineb et la Sadaqa',
      narrativeArc:
        'Fatma Bziouya s\'équipe d\'une lampe à pétrole qui suscite l\'admiration jalouse de Lalla Zoubida. Maâlem Abdeslam achète lui aussi une lampe identique le soir même. Peu après, panique collective : Zineb se perd dans la foule d\'un baptême. Retrouvée au sanctuaire des aveugles (Dar Kitoun), sa mère Rahma organise un grand repas de charité (sadaqa) pour les mendiants.',
      regionalExamKeys: [
        'Situation du passage : Disparition tragique de Zineb et réconciliation solidaire des voisins.',
        'Thèmes dominants : La solidarité communautaire traditionnelle, l\'émulation matérielle, la charité.',
        'Larmes de Sidi Mohammed : Il pleure non par amour pour Zineb, mais par contagion émotionnelle et faim.',
        'Portée morale : Le malheur efface la rancune entre Zoubida et Rahma.'
      ],
      themes: ['Lampe à pétrole', 'Disparition de Zineb', 'Solidarité fassie', 'Repas d\'aumône (Sadaqa)', 'Dar Kitoun'],
      keyCharacters: [
        { name: 'Rahma', role: 'Mère éplorée de Zineb' },
        { name: 'Zineb', role: 'Enfant égarée puis retrouvée' },
        { name: 'Fatma Bziouya', role: 'Initiatrice de la modernité (lampe)' },
        { name: 'Maâlem Abdeslam', role: 'Père généreux et digne' }
      ],
      examQuestionsHint: 'Question d\'examen : Pourquoi Sidi Mohammed pleure-t-il lors de la disparition de Zineb ?'
    },
    {
      id: 'chapitre-4',
      number: 4,
      season: 'Printemps',
      spatialFrame: 'Quartier Hajjama & Foyer familial',
      title: 'Le Printemps, les Malheurs de Moulay Larbi et Abdallah l\'Épicier',
      narrativeArc:
        'Arrivée du printemps dans la médina. Visite matinale de Lalla Zoubida et de son fils chez Lalla Aïcha au quartier Hajjama. Lalla Aïcha s\'effondre en larmes et confie la trahison de son époux Moulay Larbi, spolié par son ouvrier Abdelkader lors d\'un procès inique. Le soir, le père raconte l\'histoire fascinante d\'Abdallah l\'épicier et ses contes.',
      regionalExamKeys: [
        'Situation du passage : Début des saisons chaudes, premier grand drame social touchant les proches.',
        'Thèmes dominants : La trahison commerciale, l\'amitié féminine sincère, la tradition orale des contes.',
        'Récit enchâssé : L\'histoire d\'Abdallah l\'épicier, poète et philosophe incompris.',
        'Procédé narratif : La double énonciation et le portrait moral des personnages.'
      ],
      themes: ['Arrivée du Printemps', 'Trahison d\'Abdelkader', 'Ruine de Moulay Larbi', 'Abdallah l\'épicier', 'Contes oraux'],
      keyCharacters: [
        { name: 'Lalla Aïcha', role: 'Épouse dévouée et éprouvée' },
        { name: 'Moulay Larbi', role: 'Babouchier victime d\'injustice' },
        { name: 'Abdelkader', role: 'Associé perfide et ingrat' },
        { name: 'Abdallah l\'Épicier', role: 'Conteur mystique de la médina' }
      ],
      examQuestionsHint: 'Sujet récurrent : L\'injustice subie par Moulay Larbi et la réaction solidaire de son épouse.'
    },
  ];

  const filteredChapters = chaptersSyllabus.filter((c) => {
    if (selectedSeason !== 'all' && c.season.toLowerCase() !== selectedSeason.toLowerCase()) {
      return false;
    }
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchTitle = c.title.toLowerCase().includes(q);
      const matchNarrative = c.narrativeArc.toLowerCase().includes(q);
      const matchThemes = c.themes.some((t) => t.toLowerCase().includes(q));
      const matchChars = c.keyCharacters.some((ch) => ch.name.toLowerCase().includes(q));
      if (!matchTitle && !matchNarrative && !matchThemes && !matchChars) return false;
    }
    return true;
  });

  const completedCount = progress.completedChapters.length;
  const progressPct = Math.round((completedCount / chaptersSyllabus.length) * 100);

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Academic Syllabus Header */}
      <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 transition-colors duration-200">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-800 dark:bg-amber-500" />
            <span className="text-xs font-semibold text-amber-900 dark:text-amber-400 uppercase tracking-wider font-mono">
              Programme Officiel · 1ère Année du Baccalauréat
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 dark:text-stone-100">
            Dossiers d'Étude Chapitre par Chapitre
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 max-w-xl leading-relaxed">
            Consultez les synthèses événementielles, les figures de style incontournables et les enjeux types posés aux épreuves régionales de l'examen.
          </p>
        </div>

        {/* Academic Progress Summary Box */}
        <div className="bg-stone-50 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700 rounded-2xl p-5 shrink-0 min-w-[260px] space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-stone-700 dark:text-stone-300">Chapitres étudiés :</span>
            <span className="font-mono font-bold text-stone-900 dark:text-stone-100 tabular-nums">
              {completedCount} / {chaptersSyllabus.length} ({progressPct}%)
            </span>
          </div>

          <div className="w-full bg-stone-200 dark:bg-stone-700 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-amber-800 dark:bg-amber-500 h-2.5 rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400 pt-0.5">
            <span>État d'avancement du programme</span>
            {completedCount === chaptersSyllabus.length ? (
              <span className="font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Tous étudiés</span>
              </span>
            ) : (
              <span className="text-amber-800 dark:text-amber-400 font-medium">
                {chaptersSyllabus.length - completedCount} restant{chaptersSyllabus.length - completedCount > 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-100/70 dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 p-3.5 transition-colors duration-200">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setSelectedSeason('all')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
              selectedSeason === 'all'
                ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            Tous les chapitres ({chaptersSyllabus.length})
          </button>
          <button
            onClick={() => setSelectedSeason('hiver')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
              selectedSeason === 'hiver'
                ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            Saison Hiver (Chap. I à III)
          </button>
          <button
            onClick={() => setSelectedSeason('printemps')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
              selectedSeason === 'printemps'
                ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            Saison Printemps (Chap. IV)
          </button>
        </div>

        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher par thème, événement ou personnage..."
            className="w-full sm:w-72 px-3.5 py-2 text-xs rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 dark:placeholder:text-stone-500"
          />
        </div>
      </div>

      {/* Chapters Syllabus List */}
      <div className="space-y-6">
        {filteredChapters.map((chap, idx) => {
          const isCompleted = progress.completedChapters.includes(chap.id);
          const isExpanded = expandedChapterId === chap.id;
          const bank = quizBanks[idx];
          const quizRecord = progress.quizScores[`quiz-${chap.id}`];
          const chapterWords = lexiqueData.entries.filter((e) => e.chapterId === chap.id);

          return (
            <article
              key={chap.id}
              className={`bg-white dark:bg-stone-900 rounded-3xl border transition-all duration-200 overflow-hidden shadow-xs ${
                isCompleted
                  ? 'border-emerald-300/80 dark:border-emerald-800/80 bg-emerald-50/10 dark:bg-emerald-950/20'
                  : 'border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700'
              }`}
            >
              {/* Chapter Card Header Header */}
              <div className="p-6 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-100 dark:border-stone-800">
                <div className="flex items-start sm:items-center gap-4">
                  {/* Distinctive Chapter Badge */}
                  <div className="w-12 h-12 rounded-2xl bg-stone-900 dark:bg-stone-800 text-amber-50 dark:text-amber-300 border dark:border-stone-700 flex flex-col items-center justify-center font-serif shrink-0 shadow-xs">
                    <span className="text-[10px] uppercase font-mono tracking-wider opacity-70">Chap</span>
                    <span className="text-lg font-bold leading-none">{chap.number}</span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono text-amber-900 dark:text-amber-300 font-semibold bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 px-2 py-0.5 rounded">
                        Saison : {chap.season}
                      </span>
                      <span className="text-stone-500 dark:text-stone-400 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 dark:text-stone-500" />
                        <span>{chap.spatialFrame}</span>
                      </span>
                    </div>

                    <h3 className="font-serif font-bold text-lg sm:text-xl text-stone-900 dark:text-stone-100">
                      {chap.title}
                    </h3>
                  </div>
                </div>

                {/* Top Actions: Toggle Mastery & Accordion */}
                <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                  <button
                    onClick={() => onToggleChapter(chap.id)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors ${
                      isCompleted
                        ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-900 dark:text-emerald-300 hover:bg-emerald-200 dark:hover:bg-emerald-900'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
                    }`}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                        <span>Chapitre étudié</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-4 h-4 text-stone-400 dark:text-stone-500" />
                        <span>Marquer comme étudié</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setExpandedChapterId(isExpanded ? null : chap.id)}
                    className="p-2 rounded-xl border border-stone-200 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-600 dark:text-stone-400 transition-colors"
                    title={isExpanded ? 'Réduire' : 'Déplier les détails'}
                  >
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Chapter Card Body */}
              <div className="p-6 sm:p-7 space-y-6">
                {/* 1. Résumé Analytique */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-stone-800 dark:text-stone-200 uppercase tracking-wider">
                    <BookOpen className="w-4 h-4 text-amber-800 dark:text-amber-400" />
                    <span>Fil conducteur des événements (Incontournables) :</span>
                  </div>
                  <p className="text-xs sm:text-sm text-stone-700 dark:text-stone-300 leading-relaxed bg-stone-50 dark:bg-stone-800/60 p-4 rounded-2xl border border-stone-200 dark:border-stone-700/80 font-sans">
                    {chap.narrativeArc}
                  </p>
                </div>

                {/* 2. Expanded Study Section */}
                {isExpanded && (
                  <div className="space-y-6 pt-2 border-t border-stone-100 dark:border-stone-800 animate-in fade-in duration-200">
                    {/* Points clés pour l'examen régional */}
                    <div className="space-y-2.5">
                      <div className="flex items-center gap-2 text-xs font-bold text-stone-800 dark:text-stone-200 uppercase tracking-wider">
                        <Award className="w-4 h-4 text-amber-800 dark:text-amber-400" />
                        <span>Enjeux & Questions Types à l'Examen Régional :</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {chap.regionalExamKeys.map((keyPoint, kIdx) => (
                          <div
                            key={kIdx}
                            className="p-3.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/60 text-xs text-stone-800 dark:text-stone-200 space-y-1"
                          >
                            <span className="font-bold text-amber-950 dark:text-amber-300 block">Point #{kIdx + 1} :</span>
                            <span className="leading-relaxed">{keyPoint}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Key characters in this chapter */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-bold text-stone-800 dark:text-stone-200 uppercase tracking-wider">
                        <Users className="w-4 h-4 text-amber-800 dark:text-amber-400" />
                        <span>Personnages en action dans ce chapitre :</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {chap.keyCharacters.map((char, cIdx) => (
                          <div
                            key={cIdx}
                            className="bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2 shadow-2xs"
                          >
                            <span className="font-semibold text-stone-900 dark:text-stone-100">{char.name}</span>
                            <span className="text-[11px] text-stone-500 dark:text-stone-400 font-serif italic">({char.role})</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Vocabulary and Themes */}
                    <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                      <div className="flex flex-wrap items-center gap-1.5 text-xs">
                        <span className="text-stone-500 dark:text-stone-400 font-medium">Thèmes d'étude :</span>
                        {chap.themes.map((th, tIdx) => (
                          <span
                            key={tIdx}
                            className="bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 px-2.5 py-0.5 rounded-md text-[11px] font-medium"
                          >
                            {th}
                          </span>
                        ))}
                      </div>

                      {chapterWords.length > 0 && (
                        <div className="flex items-center gap-2 text-xs text-amber-900 dark:text-amber-400">
                          <span className="text-stone-400 dark:text-stone-500">Lexique :</span>
                          {chapterWords.map((w) => (
                            <span key={w.id} className="font-serif italic font-medium">
                              « {w.word} »
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Chapter Bottom Bar: Evaluation & Quiz Button */}
                <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="text-xs text-stone-500 dark:text-stone-400">
                    {quizRecord ? (
                      <span className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                        <span>
                          Dernier score au quiz officiel :{' '}
                          <strong className="text-stone-900 dark:text-stone-100 font-mono">
                            {quizRecord.score} / {quizRecord.total} ({Math.round((quizRecord.score / quizRecord.total) * 100)}%)
                          </strong>
                        </span>
                      </span>
                    ) : (
                      <span className="text-stone-500 dark:text-stone-400">
                        Évaluation : 18 questions types baccalauréat (QCM, Vrai/Faux, analyse)
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onOpenQuiz(idx)}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-stone-900 dark:bg-stone-800 hover:bg-stone-800 dark:hover:bg-stone-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-xs"
                    >
                      <HelpCircle className="w-4 h-4 text-amber-400" />
                      <span>Passer le Quiz officiel du Chapitre {chap.number} (18 Q)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};
