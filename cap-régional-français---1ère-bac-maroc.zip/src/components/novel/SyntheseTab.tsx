import React, { useState } from 'react';
import { SyntheseData, KnowledgeItem } from '../../types';
import { CheckCircle2, Circle, Search, Sparkles, BookOpen, Layers } from 'lucide-react';

interface SyntheseTabProps {
  data: SyntheseData;
  completedItems: string[];
  onToggleItem: (itemId: string) => void;
}

export const SyntheseTab: React.FC<SyntheseTabProps> = ({
  data,
  completedItems,
  onToggleItem,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  const categories = Array.from(
    new Set(data.knowledgeItems.map((item) => item.category))
  );

  const filteredItems = data.knowledgeItems.filter((item) => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) {
      return false;
    }
    if (search.trim() !== '') {
      const q = search.toLowerCase();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchExp = item.explanation.toLowerCase().includes(q);
      const matchCat = item.category.toLowerCase().includes(q);
      if (!matchTitle && !matchExp && !matchCat) return false;
    }
    return true;
  });

  const completedCount = completedItems.length;
  const progressPct = Math.round((completedCount / data.totalItems) * 100);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header card */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
            {data.targetAudience} · {data.totalCategories} Catégories thématiques
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900">
            {data.title}
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 max-w-xl leading-relaxed">
            {data.description}
          </p>
        </div>

        <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 shrink-0 min-w-[200px] space-y-2">
          <div className="flex items-center justify-between text-xs text-stone-600">
            <span>Points assimilés :</span>
            <span className="font-mono font-bold text-stone-900">
              {completedCount} / {data.totalItems}
            </span>
          </div>
          <div className="w-full bg-stone-200 rounded-full h-2 overflow-hidden">
            <div
              className="bg-amber-700 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <div className="text-[11px] text-stone-500 text-right font-medium">
            {progressPct}% de la synthèse maîtrisée
          </div>
        </div>
      </div>

      {/* Filter and search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-stone-100 rounded-xl border border-stone-200">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Tous ({data.totalItems})
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap capitalize ${
                selectedCategory === cat
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un concept..."
            className="w-full sm:w-64 px-3.5 py-1.5 text-xs rounded-lg border border-stone-200 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 text-stone-900 placeholder:text-stone-400"
          />
        </div>
      </div>

      {/* Grid of Knowledge Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredItems.map((item) => {
          const isDone = completedItems.includes(item.id);

          return (
            <div
              key={item.id}
              className={`rounded-xl border p-5 transition-all duration-200 flex flex-col justify-between space-y-4 ${
                isDone
                  ? 'bg-emerald-50/20 border-emerald-300'
                  : 'bg-white border-stone-200 hover:border-stone-300'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono font-semibold tracking-wider text-amber-800 bg-amber-50 border border-amber-200/60 px-2 py-0.5 rounded">
                      {item.category}
                    </span>
                    <h3 className="font-serif font-bold text-base sm:text-lg text-stone-900 pt-1">
                      {item.title}
                    </h3>
                  </div>

                  <button
                    onClick={() => onToggleItem(item.id)}
                    className={`p-1.5 rounded-lg transition-colors shrink-0 ${
                      isDone
                        ? 'text-emerald-700 bg-emerald-100 hover:bg-emerald-200'
                        : 'text-stone-400 hover:text-stone-700 hover:bg-stone-100'
                    }`}
                    title={isDone ? 'Marqué comme assimilé' : 'Marquer comme assimilé'}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    ) : (
                      <Circle className="w-5 h-5" />
                    )}
                  </button>
                </div>

                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                  {item.explanation}
                </p>
              </div>

              <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
                <span className="truncate max-w-[280px]">
                  Source : {item.source}
                </span>
                <span className="font-mono text-stone-400">#{item.id}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
