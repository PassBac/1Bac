import React, { useState } from 'react';
import { PersonnagesData, PersonnageCategory, PersonnageItem } from '../../types';
import { Users, Search, Home, MapPin } from 'lucide-react';

interface PersonnagesTabProps {
  data: PersonnagesData;
}

export const PersonnagesTab: React.FC<PersonnagesTabProps> = ({ data }) => {
  const [selectedCatId, setSelectedCatId] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  const filteredCategories = data.categories.map((cat) => {
    let filteredChars = cat.personnages;
    if (search.trim() !== '') {
      const q = search.toLowerCase();
      filteredChars = filteredChars.filter(
        (p) =>
          p.nom.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.role?.toLowerCase().includes(q) ||
          p.profession?.toLowerCase().includes(q)
      );
    }
    return {
      ...cat,
      personnages: filteredChars,
    };
  }).filter((cat) => {
    if (selectedCatId !== 'all' && cat.id !== selectedCatId) return false;
    return cat.personnages.length > 0;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Overview card */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100">
          <div>
            <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
              {data.genre} · {data.auteur}
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 mt-1">
              {data.titre}
            </h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-stone-600 bg-stone-50 border border-stone-200 px-3 py-1.5 rounded-lg shrink-0">
            <MapPin className="w-4 h-4 text-amber-700" />
            <span>Cadre spatial : {data.cadre_spatial}</span>
          </div>
        </div>

        {/* Filter and Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-stone-100 rounded-xl border border-stone-200">
            <button
              onClick={() => setSelectedCatId('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedCatId === 'all'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Tous les groupes ({data.categories.length})
            </button>
            {data.categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCatId(c.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedCatId === c.id
                    ? 'bg-white text-stone-900 shadow-xs font-semibold'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {c.nom.replace(/^[0-9.]+\s*/, '')}
              </button>
            ))}
          </div>

          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un personnage..."
              className="w-full sm:w-64 px-3.5 py-1.5 text-xs rounded-lg border border-stone-200 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 text-stone-900 placeholder:text-stone-400"
            />
          </div>
        </div>
      </div>

      {/* Render Categorized Personnages */}
      <div className="space-y-8">
        {filteredCategories.map((cat) => (
          <section key={cat.id} className="space-y-4">
            <div className="border-b border-stone-200 pb-2">
              <h3 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-700" />
                <span>{cat.nom}</span>
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">{cat.description}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {cat.personnages.map((p, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs hover:border-amber-300 transition-colors flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-serif font-bold text-base text-stone-900">
                        {p.nom}
                      </h4>
                      {p.age && (
                        <span className="text-[11px] font-mono text-stone-500 bg-stone-100 px-2 py-0.5 rounded">
                          {p.age}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-1.5 text-[11px]">
                      {p.role && (
                        <span className="font-semibold text-amber-800 bg-amber-50 border border-amber-200/60 px-2 py-0.5 rounded">
                          {p.role}
                        </span>
                      )}
                      {p.profession && (
                        <span className="text-stone-700 bg-stone-100 px-2 py-0.5 rounded">
                          {p.profession}
                        </span>
                      )}
                      {p.emplacement && (
                        <span className="text-stone-600 bg-stone-100 px-2 py-0.5 rounded">
                          {p.emplacement}
                        </span>
                      )}
                      {p.statut && (
                        <span className="text-stone-600 bg-stone-100 px-2 py-0.5 rounded">
                          {p.statut}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-stone-700 leading-relaxed pt-1">
                      {p.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
};
